export class CopilotHat {
  name = 'Copilot Hat'
  deliberate(topic, input) {
    return `🤖 Copilot: Will generate scoped TODO for "${topic}"`
  }
}