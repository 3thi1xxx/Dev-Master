export class EthicsHat {
  name = 'Ethics Hat'
  deliberate(topic, input) {
    return `⚖️ Ethics: Proceed only if no deceptive usage or misuse risks.`
  }
}