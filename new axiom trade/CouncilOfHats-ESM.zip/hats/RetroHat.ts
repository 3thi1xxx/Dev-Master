export class RetroHat {
  name = 'Retro Hat'
  deliberate(topic, input) {
    return `🧘 Retro: Let's reflect on what was learned before "${topic}"`
  }
}