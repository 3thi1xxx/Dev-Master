export class AuditorHat {
  name = 'Auditor Hat'
  deliberate(topic, input) {
    return `🔍 Auditor: Logs must be enforced for topic "${topic}"`
  }
}